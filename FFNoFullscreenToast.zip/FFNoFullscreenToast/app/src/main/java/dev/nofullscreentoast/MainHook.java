package dev.nofullscreentoast;

import android.util.Log;
import android.widget.Toast;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "FFNoFullscreenToast";
    
    // Use a ThreadLocal to safely track if we are currently inside the target method
    private static final ThreadLocal<Boolean> isInsideFullscreenMethod = ThreadLocal.withInitial(() -> false);

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        // Only target Firefox packages
        if (!lpparam.packageName.equals("org.mozilla.firefox") && 
            !lpparam.packageName.equals("org.mozilla.firefox_beta") && 
            !lpparam.packageName.equals("org.mozilla.fenix")) {
            return;
        }

        // 1. Hook the method that contains the Toast.show() call
        // Based on your Smali, the method name is exactly: fullScreenChanged$app_fenixRelease
        XposedHelpers.findAndHookMethod(
            "org.mozilla.fenix.browser.BaseBrowserFragment",
            lpparam.classLoader,
            "fullScreenChanged$app_fenixRelease",
            boolean.class, // The (Z) in Smali stands for boolean
            new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    isInsideFullscreenMethod.set(true); // "Start blocking"
                }

                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    isInsideFullscreenMethod.set(false); // "Stop blocking"
                }
            }
        );

        // 2. Hook Toast.show() and replace it with a No-Op if the flag is set
        XposedHelpers.findAndHookMethod(
            Toast.class,
            "show",
            new XC_MethodReplacement() {
                @Override
                protected Object replaceHookedMethod(MethodHookParam param) throws Throwable {
                    if (isInsideFullscreenMethod.get()) {
                        Log.d(TAG, "Successfully suppressed the fullscreen Toast.");
                        return null; // This effectively "removes" the line
                    }
                    // Otherwise, let other Toasts show normally
                    return XposedBridge.invokeOriginalMethod(param.method, param.thisObject, param.args);
                }
            }
        );
    }
}
