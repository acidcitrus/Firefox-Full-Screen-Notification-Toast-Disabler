# FFNoFullscreenToast — LSPosed Module

Silences the **"Entering full screen mode"** notification dialog that appears
whenever a website requests fullscreen in Firefox for Android (Fenix/stable/beta/Nightly).

The `about:config` flags (`full-screen-api.warning.*`) have no effect on Android
because the notification is implemented as a native Android Dialog in the Fenix app
layer (`FullScreenNotificationDialog`), completely separate from Gecko's preference
system. This module hooks that dialog's `show()` call and replaces it with a no-op.

---

## Requirements

| Requirement | Notes |
|---|---|
| Rooted Android device | Magisk or KernelSU |
| LSPosed (Zygisk edition) | v1.9.2+ recommended |
| Android Studio / Gradle | For building from source |
| Java 8+ | Included with Android Studio |

---

## Project Structure

```
FFNoFullscreenToast/
├── app/
│   └── src/main/
│       ├── java/dev/nofullscreentoast/
│       │   └── MainHook.java          ← The hook implementation
│       ├── res/values/
│       │   └── strings.xml            ← Module description + scope hint
│       ├── assets/
│       │   └── xposed_init            ← Entry-point class declaration
│       └── AndroidManifest.xml        ← Module metadata for LSPosed
├── app/build.gradle
├── build.gradle
├── settings.gradle
└── gradle.properties
```

---

## How the Hook Works

**Target class:** `mozilla.components.feature.prompts.dialog.FullScreenNotificationDialog`
**Target method:** `show()` (inherited from `android.app.Dialog`)

Firefox's `BaseBrowserFragment.onFullscreenChanged()` creates an instance of
`FullScreenNotificationDialog` and calls `.show()` on it. The module replaces that
`show()` call with a complete no-op, so the dialog object is created but never
displayed. There are no side effects — Firefox still enters fullscreen correctly,
only the notification is suppressed.

A fallback hook on `android.app.Dialog.show()` activates if the class name has
changed in your Firefox version (e.g. due to refactoring). It checks the instance's
class name at runtime and only suppresses dialogs with "FullScreenNotification" in
their name.

---

## Building

### Option A — Android Studio (easiest)

1. Open Android Studio → **File → Open** → select this folder
2. Let Gradle sync finish
3. **Build → Build Bundle(s) / APK(s) → Build APK(s)**
4. APK is at: `app/build/outputs/apk/debug/app-debug.apk`

### Option B — Command line

```bash
# From the project root:
./gradlew assembleDebug

# Output:
# app/build/outputs/apk/debug/app-debug.apk
```

### Dependency note

If `io.github.libxposed:api:100` fails to resolve, edit `app/build.gradle` and
switch to the JitPack mirror:

```groovy
dependencies {
    compileOnly 'com.github.rovo89.XposedBridge:api:82'
}
```

---

## Installation

1. **Install the APK** on your device:
   ```bash
   adb install app/build/outputs/apk/debug/app-debug.apk
   ```
   Or copy to device and install manually.

2. **Open LSPosed Manager** (the Zygisk one, not classic Xposed).

3. Go to **Modules** — you should see **"FF No Fullscreen Toast"** listed.

4. **Enable the module** (toggle it on).

5. Set the **scope**: tap the module → tap **Scope** → check the Firefox package(s)
   you use:
   - `Firefox` → `org.mozilla.firefox`
   - `Firefox Beta` → `org.mozilla.firefox_beta`
   - `Firefox Nightly` → `org.mozilla.fenix`

6. **Force stop Firefox** (or reboot if LSPosed prompts you to).

7. Open Firefox, go to any fullscreen video — the notification should be gone.

---

## Verifying It's Working

Check logcat for the module's tag:
```bash
adb logcat -s FFNoFullscreenToast
```

On a working install you'll see:
```
I FFNoFullscreenToast: Firefox package loaded: org.mozilla.firefox — installing hook
I FFNoFullscreenToast: Hook installed on mozilla.components.feature.prompts.dialog.FullScreenNotificationDialog.show()
```

When fullscreen is triggered:
```
D FFNoFullscreenToast: Suppressed FullScreenNotificationDialog.show()
```

---

## Troubleshooting

**Module doesn't appear in LSPosed Manager**
- Make sure the APK is installed (not just sideloaded to /sdcard without installing)
- Confirm the `assets/xposed_init` file is present in the APK:
  `aapt list app-debug.apk | grep xposed_init`
- Confirm the manifest has `xposedmodule` meta-data

**Module appears but hook doesn't fire**
- Ensure Firefox is in the module's scope in LSPosed Manager
- Force-stop Firefox after enabling the module; a full reboot is more reliable
- Check logcat — if you see the "could not find" warning, the fallback hook
  should still work via the class-name check

**Firefox updated and the hook stopped working**
- Mozilla occasionally refactors the dialog. Decompile the new APK with apktool
  and search for the new class name:
  ```bash
  apktool d firefox.apk -o out
  grep -r "full.screen\|fullscreen" out/smali* -il
  ```
  Update `DIALOG_CLASS` in `MainHook.java` accordingly and rebuild.

**The class was renamed / moved**
- As of Firefox ~120+, the class is confirmed at:
  `mozilla.components.feature.prompts.dialog.FullScreenNotificationDialog`
- If Mozilla moves it again, the fallback hook (which checks for "FullScreenNotification"
  in the class name) will still catch it as long as the class name stays recognizable.

---

## Supported Firefox Versions

Confirmed working target class path from Firefox ~90 through 134+. The module
includes a runtime fallback for future renames.

| Package | Channel |
|---|---|
| `org.mozilla.firefox` | Stable |
| `org.mozilla.firefox_beta` | Beta |
| `org.mozilla.fenix` | Nightly |

---

## License

Do whatever you want with this. No warranty.
